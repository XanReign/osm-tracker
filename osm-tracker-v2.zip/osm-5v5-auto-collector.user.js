// ==UserScript==
// @name         OSM 5v5 Auto Collector
// @namespace    osm5v5
// @version      1.2.0
// @description  OSM lig verilerini okur ve GitHub Pages Tracker'a güvenilir kuyruk köprüsüyle aktarır.
// @match        https://*.onlinesoccermanager.com/*
// @match        https://onlinesoccermanager.com/*
// @match        https://xanreign.github.io/osm-tracker/*
// @match        *://*/osm-tracker/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_openInTab
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  const IS_TRACKER = location.pathname.indexOf('/osm-tracker/') !== -1;
  const TABS = [
    ['league', 'LIG TABLOSU'],
    ['managers', 'MENAJER LISTESI'],
    ['squad', 'KADRO DEGERI'],
    ['goals', 'GOL']
  ];
  const COOLDOWN_MS = 5 * 60 * 1000;
  const PROTOCOL = 2;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ').trim().toUpperCase();

  function getQ() {
    try {
      const value = GM_getValue('queue', '[]');
      return Array.isArray(value) ? value : JSON.parse(value || '[]');
    } catch (_) { return []; }
  }
  function setQ(q) { GM_setValue('queue', JSON.stringify(q.slice(-60))); }
  function hash(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return 'h' + (h >>> 0).toString(36) + str.length.toString(36);
  }
  function trackerUrl() {
    let url = String(GM_getValue('trackerUrl', '') || '').trim();
    // Ayarlarda yanlışlıkla #sync kaydedildiyse çift fragment oluşmasını önle.
    return url.replace(/#.*$/, '').replace(/\/$/, '');
  }

  // ---------- Tracker sayfası: yalnızca köprü ----------
  if (IS_TRACKER) {
    const post = message => {
      message.src = 'osm-collector';
      message.protocol = PROTOCOL;
      window.postMessage(JSON.stringify(message), '*');
    };

    window.addEventListener('message', event => {
      // Firefox/Violentmonkey sandbox'ında event.source === window kontrolü
      // her zaman güvenilir olmadığından src/protocol alanlarını doğruluyoruz.
      if (typeof event.data !== 'string') return;
      let message;
      try { message = JSON.parse(event.data); } catch (_) { return; }
      if (!message || message.src !== 'osm-tracker') return;

      if (message.type === 'GET_QUEUE' || message.type === 'PING') {
        const queue = getQ();
        post({
          type: message.type === 'PING' ? 'PONG' : 'QUEUE',
          requestId: message.requestId || null,
          queue: message.type === 'PING' ? undefined : queue,
          queueSize: queue.length,
          sentAt: Date.now()
        });
      }

      if (message.type === 'ACK') {
        const ids = new Set(Array.isArray(message.ids) ? message.ids : []);
        const before = getQ();
        const after = before.filter(item => !ids.has(item.id));
        setQ(after);
        post({
          type: 'ACKED',
          requestId: message.requestId || null,
          removed: before.length - after.length,
          queueSize: after.length
        });
      }
    });

    post({ type: 'READY', queueSize: getQ().length, sentAt: Date.now() });
    return;
  }

  // ---------- OSM sayfası ----------
  const visible = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';

  function findTab(label) {
    const wanted = norm(label);
    let best = null;
    const nodes = document.querySelectorAll('a,button,li,div,span,p,h2,h3,label');
    for (const el of nodes) {
      if (!visible(el) || norm(el.innerText) !== wanted) continue;
      if (!best || best.contains(el)) best = el;
    }
    return best;
  }

  async function waitFor(fn, timeout, step) {
    const started = Date.now();
    while (Date.now() - started < timeout) {
      const value = fn();
      if (value) return value;
      await sleep(step || 500);
    }
    return null;
  }

  function settle(quiet, max) {
    quiet = quiet || 900;
    max = max || 10000;
    return new Promise(resolve => {
      let quietTimer, maxTimer;
      const observer = new MutationObserver(() => {
        clearTimeout(quietTimer);
        quietTimer = setTimeout(done, quiet);
      });
      function done() {
        observer.disconnect();
        clearTimeout(quietTimer);
        clearTimeout(maxTimer);
        resolve();
      }
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      quietTimer = setTimeout(done, quiet);
      maxTimer = setTimeout(done, max);
    });
  }

  const NUM = /^[€$£]?\s*-?\d[\d.,\s]*\s*[KkMmBb]?\s*[€$£]?$/;

  function extractRows() {
    const candidates = [];
    for (const el of document.querySelectorAll('tr,li,div,a,section')) {
      if (!visible(el)) continue;
      const text = el.innerText;
      if (!text || text.length > 400) continue;
      const lines = text.split(/[\n\t]+/).map(s => s.trim()).filter(Boolean);
      if (lines.length < 3 || lines.length > 10) continue;
      if (!/^\d{1,3}$/.test(lines[0])) continue;
      if (!NUM.test(lines[lines.length - 1])) continue;
      candidates.push({ el, lines });
    }
    const candidateSet = new Set(candidates.map(candidate => candidate.el));
    const inner = candidates.filter(candidate =>
      ![...candidate.el.querySelectorAll('*')].some(descendant => candidateSet.has(descendant))
    );
    const seen = new Set();
    const rows = [];
    inner.forEach(candidate => {
      const texts = [], numsRaw = [];
      candidate.lines.slice(1).forEach(line => (NUM.test(line) ? numsRaw : texts).push(line));
      const row = { rank: parseInt(candidate.lines[0], 10), texts, numsRaw };
      const key = JSON.stringify(row);
      if (!seen.has(key)) { seen.add(key); rows.push(row); }
    });
    return rows.sort((a, b) => a.rank - b.rank);
  }

  function parseLocalizedNumber(raw) {
    if (raw == null) return null;
    let text = String(raw).trim().replace(/[€$£\s]/g, '');
    const suffix = (text.match(/[KkMmBb]$/) || [''])[0].toUpperCase();
    text = text.replace(/[KkMmBb]$/, '');
    if (text.includes(',') && text.includes('.')) {
      // 1.234,5 biçimini 1234.5 olarak ele al.
      text = text.replace(/\./g, '').replace(',', '.');
    } else if (text.includes(',')) {
      text = text.replace(',', '.');
    }
    const number = Number(text);
    if (!Number.isFinite(number)) return null;
    const factor = suffix === 'K' ? 1e3 : suffix === 'M' ? 1e6 : suffix === 'B' ? 1e9 : 1;
    return number * factor;
  }

  function teamFromText(text) {
    const match = String(text || '').match(/\bTEAM\s+(RED|BLUE)\b/i);
    return match ? match[1].toUpperCase() : null;
  }

  // Eski texts/numsRaw alanları korunur; ek alanlar Tracker normalizer'ına
  // doğrudan okunabilir değerler sunar.
  function enrichRows(key, rows) {
    return rows.map(row => {
      const texts = row.texts || [];
      const nums = row.numsRaw || [];
      const item = Object.assign({}, row);

      if (key === 'league') {
        item.club = texts[0] || null;
        item.manager = texts[1] || null;
        item.team = teamFromText(item.club);
        item.pointsRaw = nums[0] == null ? null : nums[0];
        item.points = parseLocalizedNumber(nums[0]);
      } else if (key === 'managers') {
        item.manager = texts[0] || null;
        item.club = texts[1] || null;
        item.team = teamFromText(item.club);
        item.target = parseLocalizedNumber(nums[0]);
        item.position = parseLocalizedNumber(nums[1]);
      } else if (key === 'squad') {
        item.club = texts[0] || null;
        item.manager = texts[1] || null;
        item.team = teamFromText(item.club);
        item.valueRaw = nums[0] == null ? null : nums[0];
        item.value = parseLocalizedNumber(nums[0]);
        item.playerCount = parseLocalizedNumber(nums[1]);
        item.averageValue = parseLocalizedNumber(nums[2]);
      } else if (key === 'goals') {
        item.club = texts[0] || null;
        item.manager = texts[1] || null;
        item.team = teamFromText(item.club);
        item.scored = parseLocalizedNumber(nums[0]);
        item.conceded = parseLocalizedNumber(nums[1]);
        item.yellow = parseLocalizedNumber(nums[2]);
        item.red = parseLocalizedNumber(nums[3]);
      }
      return item;
    });
  }

  function extractHeader() {
    const lines = (document.body.innerText || '').split('\n');
    for (const line of lines) {
      if (line.indexOf('#\t') === 0) return line.split('\t').map(s => s.trim()).filter(s => s && s !== '#');
    }
    return [];
  }

  function extractScorers() {
    const lines = (document.body.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
    const index = lines.findIndex(line => norm(line) === 'GOL KRALLARI');
    const output = [];
    if (index < 0) return output;
    for (let i = index + 1; i + 2 < lines.length && /^\d{1,3}$/.test(lines[i + 2]); i += 3) {
      output.push({ player: lines[i], club: lines[i + 1], goals: parseInt(lines[i + 2], 10), team: teamFromText(lines[i + 1]) });
    }
    return output;
  }

  // Sayfa yanındaki kutu: "<tür> / <lig adı> / Moderatör / <ad> / Sezon / <no>" (gerçek sayfa çıktısından)
  function extractLeagueInfo() {
    const lines = (document.body.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
    const info = { name: null, type: null, moderator: null, season: null };
    const iMod = lines.findIndex(l => norm(l) === 'MODERATOR');
    if (iMod >= 2) { info.type = lines[iMod - 2]; info.name = lines[iMod - 1]; }
    if (iMod >= 0 && lines[iMod + 1]) info.moderator = lines[iMod + 1];
    const iSez = lines.findIndex((l, i) => norm(l) === 'SEZON' && /^\d{1,3}$/.test(lines[i + 1] || ''));
    if (iSez >= 0) info.season = parseInt(lines[iSez + 1], 10);
    return info;
  }

  let running = false;
  let statusEl = null;
  function setStatus(text) {
    GM_setValue('status', text);
    if (statusEl) statusEl.textContent = text;
  }
  function pushError(code, message) {
    const queue = getQ();
    queue.push({ kind: 'error', id: 'err-' + hash(code + message + Math.floor(Date.now() / 60000)), ts: Date.now(), error: { code, msg: message } });
    setQ(queue);
  }

  async function collect() {
    if (running) { setStatus('Toplama zaten devam ediyor…'); return; }
    running = true;
    setStatus('Toplanıyor…');
    try {
      const first = await waitFor(() => findTab(TABS[0][1]), 20000);
      if (!first) {
        setStatus('Sekme bulunamadı (yanlış sayfa / giriş / HTML değişikliği)');
        pushError('TAB_NOT_FOUND', 'LIG TABLOSU sekmesi bulunamadı: ' + location.href);
        return;
      }

      const snapshot = { v: 2, protocol: PROTOCOL, ts: Date.now(), url: location.href, tabs: {}, scorers: [] };
      let previousSignature = '';
      for (const [key, label] of TABS) {
        try {
          const tab = findTab(label);
          if (!tab) {
            snapshot.tabs[key] = { ok: false, error: 'TAB_NOT_FOUND', rows: [] };
            continue;
          }
          tab.click();
          await settle();
          const extracted = extractRows();
          const rows = enrichRows(key, extracted);
          const raw = (document.body.innerText || '').slice(0, 5000);
          const signature = JSON.stringify(extracted);
          if (!rows.length) {
            snapshot.tabs[key] = { ok: false, error: 'NO_ROWS (satır yapısı eşleşmedi)', rows: [], raw };
          } else if (key !== 'league' && signature === previousSignature) {
            snapshot.tabs[key] = { ok: false, error: 'CONTENT_UNCHANGED (sekme değişmedi)', rows: [], raw };
          } else {
            snapshot.tabs[key] = { ok: true, rows, raw, header: extractHeader() };
            previousSignature = signature;
          }
        } catch (error) {
          snapshot.tabs[key] = { ok: false, error: 'EXCEPTION ' + error.message, rows: [] };
        }
      }

      try { snapshot.scorers = extractScorers(); } catch (_) { snapshot.scorers = []; }
      try { snapshot.leagueInfo = extractLeagueInfo(); } catch (_) { snapshot.leagueInfo = null; }
      const okKeys = Object.keys(snapshot.tabs).filter(key => snapshot.tabs[key].ok);
      const summary = {};
      Object.keys(snapshot.tabs).forEach(key => {
        summary[key] = { ok: snapshot.tabs[key].ok, rows: snapshot.tabs[key].rows.length, error: snapshot.tabs[key].error || null };
      });
      const contentOnly = {};
      okKeys.forEach(key => { contentOnly[key] = snapshot.tabs[key].rows; });
      contentOnly.scorers = snapshot.scorers;
      snapshot.id = hash(JSON.stringify(contentOnly));
      GM_setValue('lastRun', JSON.stringify({
        ts: snapshot.ts, id: snapshot.id, summary, queueSizeBefore: getQ().length,
        sample: Object.keys(snapshot.tabs).reduce((out, key) => {
          out[key] = (snapshot.tabs[key].raw || '').slice(0, 800);
          return out;
        }, {}),
        structuredPreview: Object.keys(snapshot.tabs).reduce((out, key) => {
          out[key] = (snapshot.tabs[key].rows || []).slice(0, 2);
          return out;
        }, {})
      }));

      if (!okKeys.length) {
        setStatus('Hiçbir sekmeden veri alınamadı');
        pushError('NO_DATA', JSON.stringify(summary));
        return;
      }

      const queue = getQ();
      if (queue.some(item => item.id === snapshot.id)) {
        setStatus('Aynı veri zaten kuyrukta (' + queue.length + ' kayıt)');
        return;
      }
      queue.push(snapshot);
      setQ(queue);
      GM_setValue('lastAuto', Date.now());
      const failed = Object.keys(snapshot.tabs).filter(key => !snapshot.tabs[key].ok);
      setStatus('Tamamlandı — ' + okKeys.length + '/4 sekme; kuyruk: ' + queue.length +
        (failed.length ? ' (eksik: ' + failed.join(', ') + ')' : ''));

      const url = trackerUrl();
      if (url && GM_getValue('autoOpen', false)) GM_openInTab(url + '#sync', { active: true });
    } catch (error) {
      setStatus('Toplama hatası: ' + error.message);
      pushError('COLLECT_EXCEPTION', error.stack || error.message);
    } finally {
      running = false;
    }
  }

  // ---------- Küçük OSM paneli ----------
  function buildUI() {
    const base = 'position:fixed;z-index:2147483647;';
    const button = document.createElement('button');
    button.textContent = 'OSM';
    button.style.cssText = base + 'left:6px;bottom:70px;width:44px;height:44px;border-radius:22px;border:0;background:#1a73e8;color:#fff;font:bold 12px sans-serif;opacity:.85';

    const box = document.createElement('div');
    box.style.cssText = base + 'left:6px;bottom:120px;background:rgba(17,17,17,.94);color:#fff;font:13px sans-serif;padding:10px;border-radius:10px;display:none;max-width:80vw';
    statusEl = document.createElement('div');
    statusEl.style.cssText = 'margin-bottom:8px;line-height:1.4';
    statusEl.textContent = GM_getValue('status', 'Hazır');
    box.appendChild(statusEl);

    const makeButton = (label, callback) => {
      const b = document.createElement('button');
      b.textContent = label;
      b.style.cssText = 'display:block;width:100%;margin:4px 0;padding:8px;border:0;border-radius:6px;background:#333;color:#fff;font:13px sans-serif';
      b.addEventListener('click', () => {
        try { const result = callback(b); if (result && typeof result.catch === 'function') result.catch(error => setStatus('Hata: ' + error.message)); }
        catch (error) { setStatus('Hata: ' + error.message); }
      });
      box.appendChild(b);
      return b;
    };

    makeButton('Şimdi topla', () => collect());
    const autoButton = makeButton('', () => { GM_setValue('autoOn', !GM_getValue('autoOn', true)); refreshButtons(); });
    const openButton = makeButton('', () => { GM_setValue('autoOpen', !GM_getValue('autoOpen', false)); refreshButtons(); });
    makeButton('Tracker adresini ayarla', () => {
      const value = prompt('Tracker sayfası adresi (…/osm-tracker/tracker.html):', trackerUrl());
      if (value !== null) {
        const cleaned = value.trim().replace(/#.*$/, '').replace(/\/$/, '');
        GM_setValue('trackerUrl', cleaned);
        setStatus(cleaned ? 'Tracker adresi kaydedildi' : 'Tracker adresi boş');
      }
    });
    makeButton('Tracker’ı aç', () => {
      const url = trackerUrl();
      if (url) GM_openInTab(url + '#sync', { active: true });
      else setStatus('Önce Tracker adresini ayarla');
    });
    makeButton('Tanılama çıktısını kopyala', () => {
      const text = GM_getValue('lastRun', '(henüz çalışmadı)');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => setStatus('Tanılama kopyalandı'), () => prompt('Tanılama çıktısını kopyala:', text));
      } else prompt('Tanılama çıktısını kopyala:', text);
    });

    function refreshButtons() {
      autoButton.textContent = 'Otomatik toplama: ' + (GM_getValue('autoOn', true) ? 'AÇIK' : 'KAPALI');
      openButton.textContent = 'Bitince Tracker’ı aç: ' + (GM_getValue('autoOpen', false) ? 'AÇIK' : 'KAPALI');
    }
    refreshButtons();
    button.addEventListener('click', () => { box.style.display = box.style.display === 'none' ? 'block' : 'none'; });
    document.body.appendChild(box);
    document.body.appendChild(button);
  }

  buildUI();
  if (typeof GM_registerMenuCommand === 'function') GM_registerMenuCommand('OSM: şimdi topla', () => collect());

  // SPA sayfalarında sekmeler hazır olunca belirli aralıkla otomatik toplar.
  setInterval(() => {
    if (running || !GM_getValue('autoOn', true)) return;
    if (Date.now() - Number(GM_getValue('lastAuto', 0)) < COOLDOWN_MS) return;
    if (findTab(TABS[0][1]) && findTab(TABS[3][1])) collect();
  }, 3000);
})();
