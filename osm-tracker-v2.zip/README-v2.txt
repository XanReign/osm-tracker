OSM 5v5 TRACKER — v2 (toplam skor + lig adı + .xlsx)
Değişen 6 dosya: osm-5v5-auto-collector.user.js, tracker.js, tracker.html, tracker.css, score-engine.js, google-sheets-api.js
Değişmeyen: database.js, settings.js (GitHub'da kalsın)

1) 6 dosyayı GitHub'a yükle (aynı adlı dosyaların üzerine yazılır).
2) Violentmonkey'de mevcut betiğin içeriğini osm-5v5-auto-collector.user.js ile değiştir (veya adresten yeniden kur).
3) OSM'de "Şimdi topla" -> Tracker'da "Userscript'ten veri al".
4) Lig adı yalnızca yeni toplamada okunur. Üstteki "Lig:" satırında görünür.
5) "Google Sheets için indir (.xlsx)" -> Dosya iner -> Google Drive'a yükle -> Sheets ile aç. 11 sayfa hazır gelir.
